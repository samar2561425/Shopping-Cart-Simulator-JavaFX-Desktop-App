/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shoppingcart;

/**
 * Name, ID:-
 * Samar Asiri, 444000717
 * Rema Al-Ghamdi, 444001279
 * Aya Babkoor, 444002180
 * Raghad Al-Subhi, 444003965
 * 
 * Groub: 1
 */

public class BundleBuilder {
    private ProductBundle bundle;

    public void reset() {
        bundle = new ProductBundle("Unnamed Bundle");
    }

    public void addLaptop() {
        bundle.add(new SingleProduct("Laptop", 1200));
    }

    public void addMouse() {
        bundle.add(new SingleProduct("Mouse", 50));
    }

    public void addKeyboard() {
        bundle.add(new SingleProduct("Keyboard", 100));
    }

    public ProductComponent build(String name) {
        bundle = new ProductBundle(name + " - Total Items: " + bundleCount());
        addLaptop(); // optional: always add laptop
        return bundle;
    }

    private int bundleCount() {
        return 3; 
    }
}