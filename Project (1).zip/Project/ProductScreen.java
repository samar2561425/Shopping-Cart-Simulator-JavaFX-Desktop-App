/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shoppingcart;

/**
 * Name, ID:-
 * Samar Asiri, 444000717
 * Rema Al-Ghamdi, 444001279
 * Aya Babkoor, 444002180
 * Raghad Al-Subhi, 444003965
 * 
 * Groub: 1
 */

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class ProductScreen {

    private CommandManager commandManager = new CommandManager();

    public void start(Stage primaryStage) {
        primaryStage.setTitle("🛍️ Product Screen");

        ListView<ProductComponent> productList = new ListView<>();
        ListView<ProductComponent> cartList = new ListView<>();
        Label totalLabel = new Label("Total: $0.00");

        // المنتجات المتوفرة
        ProductComponent iphone = new SingleProduct("iPhone 14", 4200);
        ProductComponent ipad = new SingleProduct("iPad Air", 2800);
        ProductComponent airpods = new SingleProduct("AirPods Pro", 950);
        ProductComponent mouse = new SingleProduct("Mouse", 50);
        ProductComponent keyboard = new SingleProduct("Keyboard", 100);

        productList.getItems().addAll(iphone, ipad, airpods, mouse, keyboard);

        // الأزرار
        Button addButton = new Button("Add ➕");
        Button removeButton = new Button("Remove 🗑️");
        Button undoButton = new Button("Undo 🔁");
        Button backButton = new Button("⬅️ Back");

        addButton.setOnAction(e -> {
            ProductComponent selected = productList.getSelectionModel().getSelectedItem();
            if (selected != null) {
                // ✅ نستخدم فقط الأمر - بدون تكرار
                commandManager.executeCommand(new AddToCartCommand(selected, CartManager.getInstance().getCart()));
                updateCart(cartList, totalLabel);
            }
        });

        removeButton.setOnAction(e -> {
            ProductComponent selected = cartList.getSelectionModel().getSelectedItem();
            if (selected != null) {
                commandManager.executeCommand(new RemoveFromCartCommand(selected, CartManager.getInstance().getCart()));
                updateCart(cartList, totalLabel);
            }
        });

        undoButton.setOnAction(e -> {
            commandManager.undoLastCommand();
            updateCart(cartList, totalLabel);
        });

        backButton.setOnAction(e -> new MainScreen().start(primaryStage));

        VBox left = new VBox(10, new Label("Products:"), productList, addButton);
        VBox right = new VBox(10, new Label("Cart:"), cartList, removeButton, undoButton, totalLabel, backButton);
        HBox root = new HBox(20, left, right);
        root.setStyle("-fx-padding: 20;");

        Scene scene = new Scene(root, 800, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void updateCart(ListView<ProductComponent> cartList, Label totalLabel) {
        cartList.getItems().setAll(CartManager.getInstance().getCart());
        totalLabel.setText("Total: $" + CartManager.getInstance().getTotal());
    }
}
