/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shoppingcart;

/**
 * Name, ID:-
 * Samar Asiri, 444000717
 * Rema Al-Ghamdi, 444001279
 * Aya Babkoor, 444002180
 * Raghad Al-Subhi, 444003965
 * 
 * Groub: 1
 */

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class BundleBuilderScreen {

    private BundleBuilder builder = new BundleBuilder();

    public void start(Stage primaryStage) {
        primaryStage.setTitle("📦 Bundle Builder");

        CheckBox laptopBox = new CheckBox("Laptop");
        CheckBox mouseBox = new CheckBox("Mouse");
        CheckBox keyboardBox = new CheckBox("Keyboard");

        Button buildButton = new Button("Build Bundle ➕");
        Button backButton = new Button("⬅️ Back");

        Label resultLabel = new Label("No bundle created yet.");

        buildButton.setOnAction(e -> {
            builder.reset();
            if (laptopBox.isSelected()) builder.addLaptop();
            if (mouseBox.isSelected()) builder.addMouse();
            if (keyboardBox.isSelected()) builder.addKeyboard();

            ProductComponent bundle = builder.build("Custom Bundle");
            CartManager.getInstance().addToCart(bundle);
            resultLabel.setText("✅ Bundle added to cart: " + bundle.toString());
        });

        backButton.setOnAction(e -> new MainScreen().start(primaryStage));

        VBox box = new VBox(10,
                new Label("Select items to add to your bundle:"),
                laptopBox, mouseBox, keyboardBox,
                buildButton, resultLabel,
                backButton);
        box.setStyle("-fx-padding: 20;");

        Scene scene = new Scene(box, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
