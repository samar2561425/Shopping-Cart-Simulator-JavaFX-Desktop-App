/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shoppingcart;

/**
 * Name, ID:-
 * Samar Asiri, 444000717
 * Rema Al-Ghamdi, 444001279
 * Aya Babkoor, 444002180
 * Raghad Al-Subhi, 444003965
 * 
 * Groub: 1
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MainScreen extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("🏪 Shopping Cart - Main");

        Button productBtn = new Button("🛍️ Go to Product Screen");
        Button builderBtn = new Button("📦 Go to Bundle Builder");
        Button summaryBtn = new Button("🧾 View Cart Summary");

        productBtn.setOnAction(e -> new ProductScreen().start(primaryStage));
        builderBtn.setOnAction(e -> new BundleBuilderScreen().start(primaryStage));
        summaryBtn.setOnAction(e -> new SummaryScreen().start(primaryStage));

        VBox root = new VBox(15, productBtn, builderBtn, summaryBtn);
        root.setStyle("-fx-padding: 30; -fx-alignment: center;");

        Scene scene = new Scene(root, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
