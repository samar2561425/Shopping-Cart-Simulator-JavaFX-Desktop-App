/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shoppingcart;

/**
 * Name, ID:-
 * Samar Asiri, 444000717
 * Rema Al-Ghamdi, 444001279
 * Aya Babkoor, 444002180
 * Raghad Al-Subhi, 444003965
 * 
 * Groub: 1
 */

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class SummaryScreen {

    public void start(Stage primaryStage) {
        primaryStage.setTitle("🧾 Cart Summary");

        TextArea summaryArea = new TextArea();
        summaryArea.setEditable(false);

        Button loadButton = new Button("🔄 Load Summary");
        Button clearButton = new Button("🗑️ Clear Cart");
        Button backButton = new Button("⬅️ Back");

        loadButton.setOnAction(e -> {
            CartSummaryFacade facade = new CartSummaryFacade();
            String summary = facade.generateSummary();
            summaryArea.setText(summary);
        });

        clearButton.setOnAction(e -> {
            CartManager.getInstance().clearCart();
            summaryArea.clear();
        });

        backButton.setOnAction(e -> new MainScreen().start(primaryStage));

        VBox root = new VBox(10,
                new Label("Your Cart Summary:"),
                summaryArea,
                loadButton,
                clearButton,
                backButton
        );
        root.setStyle("-fx-padding: 20;");

        Scene scene = new Scene(root, 500, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
